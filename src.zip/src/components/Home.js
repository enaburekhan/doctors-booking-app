const Home = () => (
  <div className="card style=width: 18rem home m-4">
    <img src="https://user-images.githubusercontent.com/51296741/128604204-e71d0644-e88f-4743-b922-e708aa5a23d9.png" className="card-img-top" alt="home-page" />
    <div className="card-body" />
  </div>
);

export default Home;
