const API = 'https://agile-escarpment-87534.herokuapp.com/api/v1';

export default API;
